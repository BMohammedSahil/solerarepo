package Assignmentproject;

public class EvenValueArray {

	public static void main(String[] args) {
		int[] Arr = {1,2,3,4,5,6,7,8,9,10};
		
		for(int i=0;i<Arr.length;i++) {
			if(Arr[i]%2 ==0) {
				System.out.println(Arr[i]);
			}
		}
		
		
		

	}

}
