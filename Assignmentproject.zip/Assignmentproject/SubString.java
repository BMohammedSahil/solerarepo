package Assignmentproject;

public class SubString {

	public static void main(String[] args) {
		String str = "Helloworld";
		System.out.println(str.substring(3, 7));

	}

}
